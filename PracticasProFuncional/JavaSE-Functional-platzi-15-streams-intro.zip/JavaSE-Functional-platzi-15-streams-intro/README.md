# JavaSE-Functional-platzi
Codigo de ejemplos para el curso sobre programacion funcional de Platzi
